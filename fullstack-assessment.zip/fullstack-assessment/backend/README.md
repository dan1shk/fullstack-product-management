# Fullstack Assessment - Backend API

## Tech Stack
- Node.js with Express
- PostgreSQL (RDBMS)
- JWT Authentication
- Multer for file uploads
- ExcelJS & json2csv for report generation

## Features Implemented

### 1. User CRUD
- User registration with encrypted password (bcrypt)
- User login with JWT token generation
- User profile management (get/update)
- Get all users with pagination

### 2. Category CRUD
- Create categories with auto-generated unique IDs
- Get all categories with pagination
- Get single category
- Update category
- Delete category

### 3. Product CRUD
- Create products (must belong to a category)
- Get all products with server-side pagination, sorting, and search
- Get single product
- Update product
- Delete product

### 4. Bulk Upload (No Timeout)
- Handles large CSV file uploads
- Processes data in batches (100 records per batch)
- Streaming CSV parsing to avoid memory issues
- Transaction-based insertion for data integrity
- Returns detailed upload report

### 5. Report Generation (No Timeout)
- Download product reports in CSV or XLSX format
- Streaming data export to avoid memory issues
- No timeout errors even with large datasets

## Database Schema

### Users Table
- id (SERIAL PRIMARY KEY)
- email (VARCHAR, UNIQUE)
- password (VARCHAR - encrypted)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

### Categories Table
- id (SERIAL PRIMARY KEY)
- name (VARCHAR)
- unique_id (VARCHAR, UNIQUE - auto-generated)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

### Products Table
- id (SERIAL PRIMARY KEY)
- name (VARCHAR)
- image (VARCHAR)
- price (DECIMAL)
- unique_id (VARCHAR, UNIQUE - auto-generated)
- category_id (INTEGER - foreign key)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

## Setup Instructions

### 1. Install PostgreSQL
```bash
# Install PostgreSQL (Ubuntu/Debian)
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 2. Create Database
```bash
# Switch to postgres user
sudo -u postgres psql

# Create database
CREATE DATABASE assessment_db;

# Create user (optional)
CREATE USER assessment_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE assessment_db TO assessment_user;

# Exit
\q
```

### 3. Run Database Schema
```bash
# Run the schema file
psql -U postgres -d assessment_db -f schema.sql

# Or if using custom user
psql -U assessment_user -d assessment_db -f schema.sql
```

### 4. Install Dependencies
```bash
npm install
```

### 5. Configure Environment
```bash
# Copy the example env file
cp .env.example .env

# Edit .env with your database credentials
nano .env
```

### 6. Start Server
```bash
# Development mode (with nodemon)
npm run dev

# Production mode
npm start
```

The server will start on `http://localhost:5000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile (protected)
- `PUT /api/auth/profile` - Update user profile (protected)

### Users
- `GET /api/users` - Get all users with pagination (protected)

### Categories
- `POST /api/categories` - Create category (protected)
- `GET /api/categories` - Get all categories with pagination (protected)
- `GET /api/categories/all` - Get all categories without pagination (protected)
- `GET /api/categories/:id` - Get single category (protected)
- `PUT /api/categories/:id` - Update category (protected)
- `DELETE /api/categories/:id` - Delete category (protected)

### Products
- `POST /api/products` - Create product (protected)
- `POST /api/products/bulk-upload` - Bulk upload products via CSV (protected)
- `GET /api/products` - Get all products with pagination, sorting, search (protected)
- `GET /api/products/report?format=csv` - Download CSV report (protected)
- `GET /api/products/report?format=xlsx` - Download XLSX report (protected)
- `GET /api/products/:id` - Get single product (protected)
- `PUT /api/products/:id` - Update product (protected)
- `DELETE /api/products/:id` - Delete product (protected)

## Product List API Features

### Server-side Pagination
```
GET /api/products?page=1&limit=10
```

### Sorting by Price
```
GET /api/products?sortBy=price&sortOrder=asc
GET /api/products?sortBy=price&sortOrder=desc
```

### Search by Category and Product Names
```
GET /api/products?search=laptop
GET /api/products?category_id=1
GET /api/products?search=phone&category_id=2
```

### Combined Query
```
GET /api/products?page=1&limit=20&sortBy=price&sortOrder=asc&search=laptop&category_id=1
```

## Bulk Upload CSV Format

Create a CSV file with the following headers:
```csv
name,price,category_id,image
Product 1,99.99,1,https://example.com/image1.jpg
Product 2,149.99,1,https://example.com/image2.jpg
Product 3,79.99,2,https://example.com/image3.jpg
```

## Testing with Postman

1. Import the provided Postman collection
2. Set the base URL: `http://localhost:5000/api`
3. Register a user and get the JWT token
4. Use the token in Authorization header for protected routes: `Bearer YOUR_TOKEN`

## Error Handling

The API includes comprehensive error handling:
- Validation errors (400)
- Authentication errors (401)
- Not found errors (404)
- Server errors (500)

All responses follow this format:
```json
{
  "success": true/false,
  "message": "Response message",
  "data": { ... }
}
```

## Performance Optimizations

1. **Bulk Upload**: Batch processing (100 records at a time) to prevent timeout
2. **Report Generation**: Streaming data export to handle large datasets
3. **Database Indexes**: Created on frequently queried columns
4. **Connection Pooling**: PostgreSQL connection pool for efficient database connections
5. **Pagination**: All list endpoints support pagination to reduce data transfer

## Security Features

1. Password encryption using bcrypt
2. JWT-based authentication
3. Protected routes with authentication middleware
4. Input validation using express-validator
5. SQL injection prevention using parameterized queries
