const Product = require('../models/Product');
const Category = require('../models/Category');
const { validationResult } = require('express-validator');
const csv = require('csv-parser');
const fs = require('fs');
const { Parser } = require('json2csv');
const ExcelJS = require('exceljs');
const path = require('path');

class ProductController {
  static async create(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ 
          success: false, 
          errors: errors.array() 
        });
      }
  
      const category = await Category.findById(req.body.category_id);
      if (!category) {
        return res.status(400).json({ 
          success: false, 
          message: 'Category not found' 
        });
      }
  
      const product = await Product.create(req.body);
  
      res.status(201).json({
        success: true,
        message: 'Product created successfully',
        data: { product }
      });
    } catch (error) {
      console.error('Create product error:', error);
      res.status(500).json({ 
        success: false, 
        message: error.message || 'Server error' 
      });
    }
  }
  
  static async update(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ 
          success: false, 
          errors: errors.array() 
        });
      }
  
      const { id } = req.params;
  
      const existingProduct = await Product.findById(id);
      if (!existingProduct) {
        return res.status(404).json({ 
          success: false, 
          message: 'Product not found' 
        });
      }
  
      if (req.body.category_id) {
        const category = await Category.findById(req.body.category_id);
        if (!category) {
          return res.status(400).json({ 
            success: false, 
            message: 'Category not found' 
          });
        }
      }
  
      const product = await Product.update(id, req.body);
  
      res.json({
        success: true,
        message: 'Product updated successfully',
        data: { product }
      });
    } catch (error) {
      console.error('Update product error:', error);
      res.status(500).json({ 
        success: false, 
        message: error.message || 'Server error' 
      });
    }
  }

  static async bulkUpload(req, res) {
    try {
      if (!req.file) {
        return res.status(400).json({ 
          success: false, 
          message: 'No file uploaded' 
        });
      }

      const products = [];
      const validationErrors = [];
      const filePath = req.file.path;
      let lineNumber = 1; // Start at 1 for header

      // First, get all existing categories to validate against
      const existingCategories = await Category.getAllCategories();
      const categoryIds = existingCategories.map(cat => cat.id);
      const categoryMap = {};
      existingCategories.forEach(cat => {
        categoryMap[cat.id] = cat.name;
      });

      // Process CSV in streaming mode to avoid memory issues with large files
      const stream = fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
          lineNumber++;
          
          // Track errors for this specific row
          const rowErrors = [];

          // Validate required fields
          if (!row.name || !row.name.trim()) {
            rowErrors.push('Product name is required');
          }

          if (!row.price || isNaN(parseFloat(row.price))) {
            rowErrors.push('Valid price is required');
          }

          if (!row.category_id || isNaN(parseInt(row.category_id))) {
            rowErrors.push('Valid category_id is required');
          } else {
            // Check if category exists
            const catId = parseInt(row.category_id);
            if (!categoryIds.includes(catId)) {
              const availableCats = existingCategories
                .map(c => `${c.id}: ${c.name}`)
                .join(', ');
              rowErrors.push(
                `Category ID ${catId} does not exist. Available categories: ${availableCats}`
              );
            }
          }

          // Validate optional numeric fields
          if (row.cost_price && isNaN(parseFloat(row.cost_price))) {
            rowErrors.push('Invalid cost_price (must be a number)');
          }

          if (row.selling_price && isNaN(parseFloat(row.selling_price))) {
            rowErrors.push('Invalid selling_price (must be a number)');
          }

          if (row.mrp && isNaN(parseFloat(row.mrp))) {
            rowErrors.push('Invalid mrp (must be a number)');
          }

          if (row.primitive_quantity && isNaN(parseInt(row.primitive_quantity))) {
            rowErrors.push('Invalid primitive_quantity (must be a number)');
          }

          if (row.units_per_packaging && isNaN(parseInt(row.units_per_packaging))) {
            rowErrors.push('Invalid units_per_packaging (must be a number)');
          }

          // Validate date format
          if (row.expiry_date && row.expiry_date.trim()) {
            const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(row.expiry_date)) {
              rowErrors.push('Invalid expiry_date format (use YYYY-MM-DD)');
            }
          }

          // Validate status
          if (row.status && !['active', 'inactive', 'discontinued'].includes(row.status.toLowerCase())) {
            rowErrors.push('Invalid status (must be: active, inactive, or discontinued)');
          }

          // If there are validation errors for this row, add them to the list
          if (rowErrors.length > 0) {
            validationErrors.push({
              line: lineNumber,
              row: row.name || 'Unknown product',
              errors: rowErrors
            });
            return; // Skip this row
          }

          // Prepare product data with all fields
          const productData = {
            name: row.name.trim(),
            price: parseFloat(row.price),
            category_id: parseInt(row.category_id),
            brand: row.brand || null,
            manufacturer: row.manufacturer || null,
            description: row.description || null,
            barcode: row.barcode || null,
            image: row.image || null,
            uom: row.uom || 'piece',
            primitive_quantity: row.primitive_quantity ? parseInt(row.primitive_quantity) : 1,
            units_per_packaging: row.units_per_packaging ? parseInt(row.units_per_packaging) : 1,
            cost_price: row.cost_price ? parseFloat(row.cost_price) : null,
            selling_price: row.selling_price ? parseFloat(row.selling_price) : null,
            mrp: row.mrp ? parseFloat(row.mrp) : null,
            expiry_date: row.expiry_date || null,
            status: row.status || 'active'
          };

          products.push(productData);
        })
        .on('end', async () => {
          try {
            // If all rows had validation errors, return early
            if (products.length === 0 && validationErrors.length > 0) {
              fs.unlinkSync(filePath);
              return res.status(400).json({
                success: false,
                message: 'All products failed validation. Please fix the errors and try again.',
                data: {
                  totalRows: lineNumber - 1, // Exclude header
                  validProducts: 0,
                  invalidProducts: validationErrors.length,
                  validationErrors: validationErrors
                }
              });
            }

            // Process in batches to avoid timeout
            const batchSize = 100;
            let processedCount = 0;
            const batchErrors = [];

            for (let i = 0; i < products.length; i += batchSize) {
              const batch = products.slice(i, i + batchSize);
              
              try {
                await Product.bulkCreate(batch);
                processedCount += batch.length;
              } catch (batchError) {
                console.error(`Error processing batch ${i / batchSize + 1}:`, batchError);
                
                // Provide more detailed error message
                let errorMessage = batchError.message;
                
                // Parse specific PostgreSQL errors
                if (batchError.message.includes('foreign key constraint')) {
                  const availableCats = existingCategories
                    .map(c => `${c.id}: ${c.name}`)
                    .join(', ');
                  errorMessage = `Category not found. Please ensure all category_id values exist. Available categories: ${availableCats}`;
                } else if (batchError.message.includes('unique constraint')) {
                  errorMessage = 'Duplicate value found (barcode or unique_id already exists)';
                } else if (batchError.message.includes('violates check constraint')) {
                  errorMessage = 'Data validation failed (check numeric values and constraints)';
                }

                batchErrors.push({
                  batch: i / batchSize + 1,
                  productsInBatch: batch.length,
                  error: errorMessage
                });
              }
            }

            // Clean up uploaded file
            fs.unlinkSync(filePath);

            const totalAttempted = products.length + validationErrors.length;
            const totalFailed = (products.length - processedCount) + validationErrors.length;

            // Determine response based on results
            if (processedCount === 0 && totalFailed > 0) {
              return res.status(400).json({
                success: false,
                message: 'Bulk upload failed - no products were created',
                data: {
                  totalProducts: totalAttempted,
                  processedProducts: 0,
                  failedProducts: totalFailed,
                  validationErrors: validationErrors.length > 0 ? validationErrors : null,
                  processingErrors: batchErrors.length > 0 ? batchErrors : null,
                  hint: validationErrors.length > 0 
                    ? 'Fix the validation errors in your CSV file' 
                    : 'Check that all category IDs exist in the database'
                }
              });
            }

            res.json({
              success: true,
              message: processedCount === products.length 
                ? 'Bulk upload completed successfully' 
                : 'Bulk upload completed with some errors',
              data: {
                totalProducts: totalAttempted,
                processedProducts: processedCount,
                failedProducts: totalFailed,
                validationErrors: validationErrors.length > 0 ? validationErrors : null,
                processingErrors: batchErrors.length > 0 ? batchErrors : null
              }
            });
          } catch (error) {
            console.error('Bulk upload processing error:', error);
            if (fs.existsSync(filePath)) {
              fs.unlinkSync(filePath);
            }
            res.status(500).json({ 
              success: false, 
              message: 'Error processing bulk upload',
              error: error.message
            });
          }
        })
        .on('error', (error) => {
          console.error('CSV parsing error:', error);
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
          }
          res.status(500).json({ 
            success: false, 
            message: 'Error parsing CSV file. Please check the file format.',
            error: error.message
          });
        });

    } catch (error) {
      console.error('Bulk upload error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Server error during bulk upload',
        error: error.message
      });
    }
  }

  static async getAll(req, res) {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const offset = (page - 1) * limit;
      const sortBy = req.query.sortBy || 'created_at';
      const sortOrder = req.query.sortOrder || 'DESC';
      const searchQuery = req.query.search || '';
      const categoryId = req.query.category_id ? parseInt(req.query.category_id) : null;
      const status = req.query.status || null;

      const options = {
        limit,
        offset,
        sortBy,
        sortOrder,
        searchQuery,
        categoryId,
        status
      };

      const products = await Product.getAll(options);
      const total = await Product.count({ searchQuery, categoryId, status });

      res.json({
        success: true,
        data: {
          products,
          pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit)
          }
        }
      });
    } catch (error) {
      console.error('Get all products error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Server error' 
      });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const product = await Product.findById(id);

      if (!product) {
        return res.status(404).json({ 
          success: false, 
          message: 'Product not found' 
        });
      }

      res.json({
        success: true,
        data: { product }
      });
    } catch (error) {
      console.error('Get product error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Server error' 
      });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;

      const existingProduct = await Product.findById(id);
      if (!existingProduct) {
        return res.status(404).json({ 
          success: false, 
          message: 'Product not found' 
        });
      }

      await Product.delete(id);

      res.json({
        success: true,
        message: 'Product deleted successfully'
      });
    } catch (error) {
      console.error('Delete product error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Server error' 
      });
    }
  }

  static async generateReport(req, res) {
    try {
      const format = req.query.format || 'csv';

      // Fetch all products in streaming fashion to avoid memory issues
      const products = await Product.getAllForExport();

      if (format === 'csv') {
        // Include all fields in CSV export
        const fields = [
          { label: 'Product ID', value: 'unique_id' },
          { label: 'Product Name', value: 'name' },
          { label: 'Brand', value: 'brand' },
          { label: 'Manufacturer', value: 'manufacturer' },
          { label: 'Description', value: 'description' },
          { label: 'Barcode', value: 'barcode' },
          { label: 'UOM', value: 'uom' },
          { label: 'Primitive Quantity', value: 'primitive_quantity' },
          { label: 'Units Per Packaging', value: 'units_per_packaging' },
          { label: 'Display Price', value: 'price' },
          { label: 'Cost Price', value: 'cost_price' },
          { label: 'Selling Price', value: 'selling_price' },
          { label: 'MRP', value: 'mrp' },
          { label: 'Category', value: 'category_name' },
          { label: 'Category ID', value: 'category_unique_id' },
          { label: 'Image URL', value: 'image' },
          { label: 'Expiry Date', value: 'expiry_date' },
          { label: 'Status', value: 'status' },
          { label: 'Created At', value: 'created_at' },
          { label: 'Updated At', value: 'updated_at' }
        ];
        
        const json2csvParser = new Parser({ fields });
        const csv = json2csvParser.parse(products);

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=products-report.csv');
        res.send(csv);
      } else if (format === 'xlsx') {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Products');

        // Define columns with all fields
        worksheet.columns = [
          { header: 'Product ID', key: 'unique_id', width: 20 },
          { header: 'Product Name', key: 'name', width: 30 },
          { header: 'Brand', key: 'brand', width: 20 },
          { header: 'Manufacturer', key: 'manufacturer', width: 25 },
          { header: 'Description', key: 'description', width: 40 },
          { header: 'Barcode', key: 'barcode', width: 20 },
          { header: 'UOM', key: 'uom', width: 12 },
          { header: 'Primitive Quantity', key: 'primitive_quantity', width: 18 },
          { header: 'Units Per Packaging', key: 'units_per_packaging', width: 18 },
          { header: 'Display Price', key: 'price', width: 15 },
          { header: 'Cost Price', key: 'cost_price', width: 15 },
          { header: 'Selling Price', key: 'selling_price', width: 15 },
          { header: 'MRP', key: 'mrp', width: 15 },
          { header: 'Category', key: 'category_name', width: 20 },
          { header: 'Category ID', key: 'category_unique_id', width: 20 },
          { header: 'Image URL', key: 'image', width: 40 },
          { header: 'Expiry Date', key: 'expiry_date', width: 15 },
          { header: 'Status', key: 'status', width: 12 },
          { header: 'Created At', key: 'created_at', width: 20 },
          { header: 'Updated At', key: 'updated_at', width: 20 }
        ];

        // Style header row
        worksheet.getRow(1).font = { bold: true };
        worksheet.getRow(1).fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FF4472C4' }
        };
        worksheet.getRow(1).font = { color: { argb: 'FFFFFFFF' }, bold: true };

        // Add data
        products.forEach(product => {
          worksheet.addRow(product);
        });

        res.setHeader(
          'Content-Type',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );
        res.setHeader('Content-Disposition', 'attachment; filename=products-report.xlsx');

        await workbook.xlsx.write(res);
        res.end();
      } else {
        return res.status(400).json({ 
          success: false, 
          message: 'Invalid format. Use csv or xlsx' 
        });
      }
    } catch (error) {
      console.error('Generate report error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Server error during report generation' 
      });
    }
  }
}

module.exports = ProductController;