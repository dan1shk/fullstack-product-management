const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class Category {
  static async create(name, parentCategoryId = null, status = 'active') {
    const uniqueId = `CAT-${uuidv4().split('-')[0].toUpperCase()}`;
    const result = await db.query(
      'INSERT INTO categories (name, unique_id, parent_category_id, status) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, uniqueId, parentCategoryId, status]
    );
    return result.rows[0];
  }
  static async findById(id) {
    const result = await db.query(
      'SELECT * FROM categories WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  static async findByUniqueId(uniqueId) {
    const result = await db.query(
      'SELECT * FROM categories WHERE unique_id = $1',
      [uniqueId]
    );
    return result.rows[0];
  }

  static async update(id, name, parentCategoryId = null, status = 'active') {
    const result = await db.query(
      'UPDATE categories SET name = $1, parent_category_id = $2, status = $3 WHERE id = $4 RETURNING *',
      [name, parentCategoryId, status, id]
    );
    return result.rows[0];
  }

  static async delete(id) {
    await db.query('DELETE FROM categories WHERE id = $1', [id]);
  }

  static async getAll(limit = 10, offset = 0) {
    const result = await db.query(
      'SELECT * FROM categories ORDER BY created_at DESC LIMIT $1 OFFSET $2',
      [limit, offset]
    );
    return result.rows;
  }

  static async count() {
    const result = await db.query('SELECT COUNT(*) FROM categories');
    return parseInt(result.rows[0].count);
  }

  static async getAllCategories() {
    const result = await db.query(`
      SELECT c.*, pc.name as parent_category_name 
      FROM categories c 
      LEFT JOIN categories pc ON c.parent_category_id = pc.id 
      ORDER BY c.name ASC
    `);
    return result.rows;
  }
}

module.exports = Category;
