const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class Product {
  static async create(productData) {
    const {
      name, image, price, category_id, brand, manufacturer, description,
      barcode, uom, primitive_quantity, units_per_packaging, cost_price,
      selling_price, mrp, expiry_date, status
    } = productData;

    const uniqueId = `PRD-${uuidv4().split('-')[0].toUpperCase()}`;
    
    // Auto-generate barcode if not provided
    let finalBarcode = barcode;
    if (!finalBarcode) {
      const barcodeResult = await db.query('SELECT generate_barcode() as barcode');
      finalBarcode = barcodeResult.rows[0].barcode;
    }

    const result = await db.query(
      `INSERT INTO products (
        name, image, price, unique_id, category_id, brand, manufacturer, 
        description, barcode, uom, primitive_quantity, units_per_packaging, 
        cost_price, selling_price, mrp, expiry_date, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17) 
      RETURNING *`,
      [
        name, image, price, uniqueId, category_id, brand, manufacturer,
        description, finalBarcode, uom || 'piece', primitive_quantity || 1,
        units_per_packaging || 1, cost_price, selling_price, mrp,
        expiry_date, status || 'active'
      ]
    );
    return result.rows[0];
  }

  static async bulkCreate(products) {
    const client = await db.pool.connect();
    try {
      await client.query('BEGIN');
      
      const insertedProducts = [];
      for (const product of products) {
        const uniqueId = `PRD-${uuidv4().split('-')[0].toUpperCase()}`;
        
        // Auto-generate barcode if not provided
        let barcode = product.barcode;
        if (!barcode) {
          const barcodeResult = await client.query('SELECT generate_barcode() as barcode');
          barcode = barcodeResult.rows[0].barcode;
        }

        const result = await client.query(
          `INSERT INTO products (
            name, image, price, unique_id, category_id, brand, manufacturer,
            description, barcode, uom, primitive_quantity, units_per_packaging,
            cost_price, selling_price, mrp, expiry_date, status
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17) 
          RETURNING *`,
          [
            product.name, product.image, product.price, uniqueId, product.category_id,
            product.brand, product.manufacturer, product.description, barcode,
            product.uom || 'piece', product.primitive_quantity || 1,
            product.units_per_packaging || 1, product.cost_price, product.selling_price,
            product.mrp, product.expiry_date, product.status || 'active'
          ]
        );
        insertedProducts.push(result.rows[0]);
      }
      
      await client.query('COMMIT');
      return insertedProducts;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  static async findById(id) {
    const result = await db.query(
      `SELECT p.*, c.name as category_name 
       FROM products p 
       LEFT JOIN categories c ON p.category_id = c.id 
       WHERE p.id = $1`,
      [id]
    );
    return result.rows[0];
  }

  static async findByUniqueId(uniqueId) {
    const result = await db.query(
      `SELECT p.*, c.name as category_name 
       FROM products p 
       LEFT JOIN categories c ON p.category_id = c.id 
       WHERE p.unique_id = $1`,
      [uniqueId]
    );
    return result.rows[0];
  }

  static async update(id, productData) {
    const {
      name, image, price, category_id, brand, manufacturer, description,
      barcode, uom, primitive_quantity, units_per_packaging, cost_price,
      selling_price, mrp, expiry_date, status
    } = productData;

    const result = await db.query(
      `UPDATE products SET 
        name = $1, image = $2, price = $3, category_id = $4, brand = $5,
        manufacturer = $6, description = $7, barcode = $8, uom = $9,
        primitive_quantity = $10, units_per_packaging = $11, cost_price = $12,
        selling_price = $13, mrp = $14, expiry_date = $15, status = $16
      WHERE id = $17 RETURNING *`,
      [
        name, image, price, category_id, brand, manufacturer, description,
        barcode, uom, primitive_quantity, units_per_packaging, cost_price,
        selling_price, mrp, expiry_date, status, id
      ]
    );
    return result.rows[0];
  }

  static async delete(id) {
    await db.query('DELETE FROM products WHERE id = $1', [id]);
  }

  static async getAll(options = {}) {
    const {
      limit = 10,
      offset = 0,
      sortBy = 'created_at',
      sortOrder = 'DESC',
      searchQuery = '',
      categoryId = null,
      status = null
    } = options;

    let query = `
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 1;

    if (searchQuery) {
      query += ` AND (p.name ILIKE $${paramCount} OR c.name ILIKE $${paramCount} OR p.brand ILIKE $${paramCount} OR p.barcode ILIKE $${paramCount})`;
      params.push(`%${searchQuery}%`);
      paramCount++;
    }

    if (categoryId) {
      query += ` AND p.category_id = $${paramCount}`;
      params.push(categoryId);
      paramCount++;
    }

    if (status) {
      query += ` AND p.status = $${paramCount}`;
      params.push(status);
      paramCount++;
    }

    const validSortColumns = ['price', 'name', 'created_at', 'brand', 'expiry_date', 'selling_price', 'mrp'];
    const sortColumn = validSortColumns.includes(sortBy) ? sortBy : 'created_at';
    const order = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
    
    query += ` ORDER BY p.${sortColumn} ${order}`;
    query += ` LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const result = await db.query(query, params);
    return result.rows;
  }

  static async count(options = {}) {
    const { searchQuery = '', categoryId = null, status = null } = options;

    let query = `
      SELECT COUNT(*) 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 1;

    if (searchQuery) {
      query += ` AND (p.name ILIKE $${paramCount} OR c.name ILIKE $${paramCount} OR p.brand ILIKE $${paramCount} OR p.barcode ILIKE $${paramCount})`;
      params.push(`%${searchQuery}%`);
      paramCount++;
    }

    if (categoryId) {
      query += ` AND p.category_id = $${paramCount}`;
      params.push(categoryId);
      paramCount++;
    }

    if (status) {
      query += ` AND p.status = $${paramCount}`;
      params.push(status);
      paramCount++;
    }

    const result = await db.query(query, params);
    return parseInt(result.rows[0].count);
  }

  static async getAllForExport() {
    const result = await db.query(`
      SELECT 
        p.unique_id, p.name, p.brand, p.manufacturer, p.description,
        p.barcode, p.uom, p.primitive_quantity, p.units_per_packaging,
        p.price, p.cost_price, p.selling_price, p.mrp, p.image,
        p.expiry_date, p.status,
        c.name as category_name, c.unique_id as category_unique_id,
        p.created_at, p.updated_at
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      ORDER BY p.created_at DESC
    `);
    return result.rows;
  }
}

module.exports = Product;