const db = require('../config/database');
const bcrypt = require('bcrypt');

class User {
  static async create(email, password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await db.query(
      'INSERT INTO users (email, password) VALUES ($1, $2) RETURNING id, email, created_at',
      [email, hashedPassword]
    );
    return result.rows[0];
  }

  static async findByEmail(email) {
    const result = await db.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    return result.rows[0];
  }

  static async findById(id) {
    const result = await db.query(
      'SELECT id, email, created_at, updated_at FROM users WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  static async update(id, email, password) {
    let query = 'UPDATE users SET email = $1';
    let params = [email];
    
    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      query += ', password = $2 WHERE id = $3 RETURNING id, email, updated_at';
      params.push(hashedPassword, id);
    } else {
      query += ' WHERE id = $2 RETURNING id, email, updated_at';
      params.push(id);
    }
    
    const result = await db.query(query, params);
    return result.rows[0];
  }

  static async delete(id) {
    await db.query('DELETE FROM users WHERE id = $1', [id]);
  }

  static async verifyPassword(plainPassword, hashedPassword) {
    return bcrypt.compare(plainPassword, hashedPassword);
  }

  static async getAll(limit = 10, offset = 0) {
    const result = await db.query(
      'SELECT id, email, created_at, updated_at FROM users ORDER BY created_at DESC LIMIT $1 OFFSET $2',
      [limit, offset]
    );
    return result.rows;
  }

  static async count() {
    const result = await db.query('SELECT COUNT(*) FROM users');
    return parseInt(result.rows[0].count);
  }
}

module.exports = User;
