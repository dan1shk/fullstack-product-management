const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const UserController = require('../controllers/userController');
const CategoryController = require('../controllers/categoryController');
const ProductController = require('../controllers/productController');
const authMiddleware = require('../middleware/auth');
const { 
  userValidationRules, 
  categoryValidationRules, 
  productValidationRules 
} = require('../validators/validators');

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10485760 // 10MB default
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv') {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

// User routes
router.post('/auth/register', userValidationRules.register, UserController.register);
router.post('/auth/login', userValidationRules.login, UserController.login);
router.get('/auth/profile', authMiddleware, UserController.getProfile);
router.put('/auth/profile', authMiddleware, userValidationRules.update, UserController.updateProfile);
router.get('/users', authMiddleware, UserController.getAllUsers);

// Category routes
router.post('/categories', authMiddleware, categoryValidationRules.create, CategoryController.create);
router.get('/categories', authMiddleware, CategoryController.getAll);
router.get('/categories/all', authMiddleware, CategoryController.getAllCategories);
router.get('/categories/:id', authMiddleware, CategoryController.getById);
router.put('/categories/:id', authMiddleware, categoryValidationRules.update, CategoryController.update);
router.delete('/categories/:id', authMiddleware, CategoryController.delete);

// Product routes
router.post('/products', authMiddleware, productValidationRules.create, ProductController.create);
router.post('/products/bulk-upload', authMiddleware, upload.single('file'), ProductController.bulkUpload);
router.get('/products', authMiddleware, ProductController.getAll);
router.get('/products/report', authMiddleware, ProductController.generateReport);
router.get('/products/:id', authMiddleware, ProductController.getById);
router.put('/products/:id', authMiddleware, productValidationRules.update, ProductController.update);
router.delete('/products/:id', authMiddleware, ProductController.delete);

module.exports = router;
