-- Database Schema for Fullstack Assessment
-- Complete schema with all fields for products and categories

-- Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Categories Table (with hierarchical support)
CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    unique_id VARCHAR(50) UNIQUE NOT NULL,
    parent_category_id INTEGER,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_parent_category FOREIGN KEY (parent_category_id) 
        REFERENCES categories(id) ON DELETE SET NULL
);

-- Create Products Table (with all fields)
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    brand VARCHAR(255),
    manufacturer VARCHAR(255),
    description TEXT,
    barcode VARCHAR(100) UNIQUE,
    image VARCHAR(500),
    price DECIMAL(10, 2) NOT NULL,
    cost_price DECIMAL(10, 2),
    selling_price DECIMAL(10, 2),
    mrp DECIMAL(10, 2),
    uom VARCHAR(50) DEFAULT 'piece',
    primitive_quantity INTEGER DEFAULT 1,
    units_per_packaging INTEGER DEFAULT 1,
    expiry_date DATE,
    status VARCHAR(20) DEFAULT 'active',
    unique_id VARCHAR(50) UNIQUE NOT NULL,
    category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
-- Products indexes
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_price ON products(price);
CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand);
CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_expiry_date ON products(expiry_date);

-- Categories indexes
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name);
CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_category_id);
CREATE INDEX IF NOT EXISTS idx_categories_status ON categories(status);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for automatic updated_at updates
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_categories_updated_at ON categories;
CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_products_updated_at ON products;
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to auto-generate barcode
CREATE OR REPLACE FUNCTION generate_barcode()
RETURNS VARCHAR AS $$
DECLARE
  new_barcode VARCHAR;
  barcode_exists BOOLEAN;
BEGIN
  LOOP
    -- Generate random 13-digit barcode (EAN-13 format)
    new_barcode := LPAD(FLOOR(RANDOM() * 10000000000000)::TEXT, 13, '0');
    
    -- Check if barcode already exists
    SELECT EXISTS(SELECT 1 FROM products WHERE barcode = new_barcode) INTO barcode_exists;
    
    -- Exit loop if unique
    EXIT WHEN NOT barcode_exists;
  END LOOP;
  
  RETURN new_barcode;
END;
$$ LANGUAGE plpgsql;

-- Success message
DO $$
BEGIN
    RAISE NOTICE '===================================';
    RAISE NOTICE 'Database schema created successfully!';
    RAISE NOTICE '===================================';
    RAISE NOTICE 'Tables created:';
    RAISE NOTICE '  - users';
    RAISE NOTICE '  - categories';
    RAISE NOTICE '  - products ';
    RAISE NOTICE '';
    RAISE NOTICE 'Ready to use!';
END $$;