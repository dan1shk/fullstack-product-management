const { body } = require('express-validator');

const userValidationRules = {
  register: [
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email')
      .normalizeEmail(),
    body('password')
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters long')
  ],
  login: [
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email')
      .normalizeEmail(),
    body('password')
      .notEmpty()
      .withMessage('Password is required')
  ],
  update: [
    body('email')
      .optional()
      .isEmail()
      .withMessage('Please provide a valid email')
      .normalizeEmail(),
    body('password')
      .optional()
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters long')
  ]
};

const categoryValidationRules = {
  create: [
    body('name')
      .notEmpty()
      .withMessage('Category name is required')
      .isLength({ min: 2, max: 255 })
      .withMessage('Category name must be between 2 and 255 characters')
  ],
  update: [
    body('name')
      .notEmpty()
      .withMessage('Category name is required')
      .isLength({ min: 2, max: 255 })
      .withMessage('Category name must be between 2 and 255 characters')
  ]
};

const productValidationRules = {
  create: [
    body('name')
      .notEmpty()
      .withMessage('Product name is required')
      .isLength({ min: 2, max: 255 })
      .withMessage('Product name must be between 2 and 255 characters'),
    body('price')
      .notEmpty()
      .withMessage('Price is required')
      .isFloat({ min: 0 })
      .withMessage('Price must be a positive number'),
    body('category_id')
      .notEmpty()
      .withMessage('Category ID is required')
      .isInt()
      .withMessage('Category ID must be a valid integer'),
    body('image')
      .optional()
      .isURL()
      .withMessage('Image must be a valid URL')
  ],
  update: [
    body('name')
      .optional()
      .isLength({ min: 2, max: 255 })
      .withMessage('Product name must be between 2 and 255 characters'),
    body('price')
      .optional()
      .isFloat({ min: 0 })
      .withMessage('Price must be a positive number'),
    body('category_id')
      .optional()
      .isInt()
      .withMessage('Category ID must be a valid integer'),
    body('image')
      .optional()
      .isURL()
      .withMessage('Image must be a valid URL')
  ]
};

module.exports = {
  userValidationRules,
  categoryValidationRules,
  productValidationRules
};
