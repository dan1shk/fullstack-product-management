import { Component } from '@angular/core';

@Component({
  selector: 'app-category-form',
  standalone: true,
  imports: [],
  templateUrl: './category-form.component.html',
  styleUrl: './category-form.component.css'
})
export class CategoryFormComponent {

}
