import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CategoryService, Category } from '../../../services/category.service';

@Component({
  selector: 'app-category-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {
  categories: Category[] = [];
  loading: boolean = false;
  errorMessage: string = '';
  
  // Form
  showForm: boolean = false;
  editMode: boolean = false;
  categoryForm = {
    name: '',
    parent_category_id: null as number | null,
    status: 'active',
    unique_id: ''
  };
  editingId: number | null = null;
  canEditUniqueId: boolean = false;

  constructor(private categoryService: CategoryService) {}

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.loading = true;
    this.categoryService.getAllCategories().subscribe({
      next: (response) => {
        if (response.success && response.data.categories) {
          this.categories = response.data.categories;
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load categories';
        this.loading = false;
      }
    });
  }

  showCreateForm() {
    this.showForm = true;
    this.editMode = false;
    this.categoryForm = { name: '', parent_category_id: null, status: 'active', unique_id: '' };
    this.editingId = null;
    this.canEditUniqueId = false;
  }

  showEditForm(category: Category) {
    this.showForm = true;
    this.editMode = true;
    this.categoryForm = {
      name: category.name,
      parent_category_id: category.parent_category_id || null,
      status: category.status,
      unique_id: category.unique_id
    };
    this.editingId = category.id;
    this.canEditUniqueId = true;
  }

  cancelForm() {
    this.showForm = false;
    this.categoryForm = { name: '', parent_category_id: null, status: 'active', unique_id: '' };
    this.editingId = null;
  }

  saveCategory() {
    if (!this.categoryForm.name.trim()) {
      alert('Please enter a category name');
      return;
    }

    if (this.editMode && this.editingId) {
      this.categoryService.updateCategory(
        this.editingId, 
        this.categoryForm.name,
        this.categoryForm.parent_category_id,
        this.categoryForm.status
      ).subscribe({
        next: () => {
          this.loadCategories();
          this.cancelForm();
          alert('Category updated successfully!');
        },
        error: (error) => {
          alert('Failed to update category');
        }
      });
    } else {
      this.categoryService.createCategory(
        this.categoryForm.name,
        this.categoryForm.parent_category_id,
        this.categoryForm.status
      ).subscribe({
        next: () => {
          this.loadCategories();
          this.cancelForm();
          alert('Category created successfully!');
        },
        error: (error) => {
          alert('Failed to create category');
        }
      });
    }
  }

  deleteCategory(id: number) {
    if (confirm('Are you sure? This will delete all products in this category!')) {
      this.categoryService.deleteCategory(id).subscribe({
        next: () => {
          this.loadCategories();
        },
        error: (error) => {
          alert('Failed to delete category');
        }
      });
    }
  }
}