import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ProductService, Product } from '../../services/product.service';
import { CategoryService, Category } from '../../services/category.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  recentProducts: Product[] = [];
  recentCategories: Category[] = [];
  totalProducts: number = 0;
  totalCategories: number = 0;
  loading: boolean = true;
  currentUser: any = null;

  constructor(
    private authService: AuthService,
    private productService: ProductService,
    private categoryService: CategoryService
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    this.loadDashboardData();
  }

  loadDashboardData() {
    this.productService.getProducts({ page: 1, limit: 6 }).subscribe({
      next: (response) => {
        if (response.success) {
          this.recentProducts = response.data.products || [];
          this.totalProducts = response.data.pagination?.total || 0;
        }
      },
      error: (error) => console.error('Error loading products:', error)
    });

    this.categoryService.getCategories(1, 6).subscribe({
      next: (response) => {
        if (response.success) {
          this.recentCategories = response.data.categories || [];
          this.totalCategories = response.data.pagination?.total || 0;
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading categories:', error);
        this.loading = false;
      }
    });
  }

  logout() {
    this.authService.logout();
  }
}