import { Component } from '@angular/core';

@Component({
  selector: 'app-product-bulk-upload',
  standalone: true,
  imports: [],
  templateUrl: './product-bulk-upload.component.html',
  styleUrl: './product-bulk-upload.component.css'
})
export class ProductBulkUploadComponent {

}
