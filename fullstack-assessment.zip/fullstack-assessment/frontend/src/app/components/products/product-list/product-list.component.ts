import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProductService, Product } from '../../../services/product.service';
import { CategoryService, Category } from '../../../services/category.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  categories: Category[] = [];
  loading: boolean = false;
  errorMessage: string = '';

  // Pagination
  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 0;
  totalProducts: number = 0;

  // Filters
  searchQuery: string = '';
  selectedCategoryId: number | null = null;
  sortBy: string = 'created_at';
  sortOrder: 'asc' | 'desc' = 'desc';

  // Upload
  selectedFile: File | null = null;
  uploadMessage: string = '';
  uploadErrors: any[] = [];
  showUploadDetails: boolean = false;

  constructor(
    private productService: ProductService,
    private categoryService: CategoryService
  ) {}

  ngOnInit() {
    this.loadCategories();
    this.loadProducts();
  }

  loadCategories() {
    this.categoryService.getAllCategories().subscribe({
      next: (response) => {
        if (response.success && response.data.categories) {
          this.categories = response.data.categories;
        }
      },
      error: (error) => {
        console.error('Error loading categories:', error);
      }
    });
  }

  loadProducts() {
    this.loading = true;
    this.errorMessage = '';

    const filters = {
      page: this.currentPage,
      limit: this.pageSize,
      sortBy: this.sortBy,
      sortOrder: this.sortOrder,
      search: this.searchQuery || undefined,
      category_id: this.selectedCategoryId || undefined
    };

    this.productService.getProducts(filters).subscribe({
      next: (response) => {
        if (response.success && response.data.products) {
          this.products = response.data.products;
          if (response.data.pagination) {
            this.totalPages = response.data.pagination.totalPages;
            this.totalProducts = response.data.pagination.total;
          }
        }
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load products';
        this.loading = false;
      }
    });
  }

  onSearch() {
    this.currentPage = 1;
    this.loadProducts();
  }

  onCategoryFilter() {
    this.currentPage = 1;
    this.loadProducts();
  }

  onSort(column: string) {
    if (this.sortBy === column) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortBy = column;
      this.sortOrder = 'asc';
    }
    this.loadProducts();
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadProducts();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.loadProducts();
    }
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    this.uploadMessage = '';
    this.uploadErrors = [];
    this.showUploadDetails = false;
  }

  uploadCSV() {
    if (!this.selectedFile) {
      this.uploadMessage = 'Please select a file';
      return;
    }

    this.loading = true;
    this.uploadMessage = 'Uploading...';
    this.uploadErrors = [];
    this.showUploadDetails = false;

    this.productService.bulkUpload(this.selectedFile).subscribe({
      next: (response) => {
        this.loading = false;
        
        if (response.success) {
          const processed = response.data.processedProducts;
          const failed = response.data.failedProducts;
          const total = response.data.totalProducts;
          
          if (processed === total) {
            this.uploadMessage = `✅ Success! All ${processed} products uploaded successfully!`;
          } else if (processed > 0) {
            this.uploadMessage = `⚠️ Partial Success: ${processed} products uploaded, ${failed} failed.`;
          } else {
            this.uploadMessage = `❌ Upload Failed: 0 products uploaded, ${failed} failed.`;
          }

          // Store errors for detailed display
          this.uploadErrors = [];
          
          if (response.data.validationErrors && response.data.validationErrors.length > 0) {
            this.uploadErrors.push({
              type: 'Validation Errors',
              items: response.data.validationErrors
            });
          }
          
          if (response.data.processingErrors && response.data.processingErrors.length > 0) {
            this.uploadErrors.push({
              type: 'Processing Errors',
              items: response.data.processingErrors
            });
          }

          this.showUploadDetails = this.uploadErrors.length > 0;
          this.selectedFile = null;
          
          if (processed > 0) {
            this.loadProducts();
          }
        } else {
          this.uploadMessage = `❌ Error: ${response.message}`;
          if (response.data.validationErrors || response.data.processingErrors) {
            this.uploadErrors = [];
            
            if (response.data.validationErrors) {
              this.uploadErrors.push({
                type: 'Validation Errors',
                items: response.data.validationErrors
              });
            }
            
            if (response.data.processingErrors) {
              this.uploadErrors.push({
                type: 'Processing Errors',
                items: response.data.processingErrors
              });
            }
            
            this.showUploadDetails = true;
          }
        }
      },
      error: (error) => {
        this.loading = false;
        console.error('Upload error:', error);
        
        if (error.error && error.error.data) {
          const data = error.error.data;
          this.uploadMessage = `❌ ${error.error.message || 'Upload failed'}`;
          
          this.uploadErrors = [];
          
          if (data.validationErrors && data.validationErrors.length > 0) {
            this.uploadErrors.push({
              type: 'Validation Errors',
              items: data.validationErrors
            });
          }
          
          if (data.processingErrors && data.processingErrors.length > 0) {
            this.uploadErrors.push({
              type: 'Processing Errors',
              items: data.processingErrors
            });
          }
          
          this.showUploadDetails = this.uploadErrors.length > 0;
        } else {
          this.uploadMessage = `❌ Upload failed: ${error.error?.message || error.message || 'Unknown error'}`;
        }
      }
    });
  }

  toggleUploadDetails() {
    this.showUploadDetails = !this.showUploadDetails;
  }

  downloadCSV() {
    this.productService.downloadReportAsFile('csv');
  }

  downloadExcel() {
    this.productService.downloadReportAsFile('xlsx');
  }

  deleteProduct(id: number) {
    if (confirm('Are you sure you want to delete this product?')) {
      this.productService.deleteProduct(id).subscribe({
        next: () => {
          this.loadProducts();
        },
        error: (error) => {
          alert('Failed to delete product');
        }
      });
    }
  }

  // Form properties
  showForm: boolean = false;
  editMode: boolean = false;
  productForm = {
    name: '',
    brand: '',
    manufacturer: '',
    description: '',
    barcode: '',
    price: 0,
    cost_price: 0,
    selling_price: 0,
    mrp: 0,
    category_id: null as number | null,
    image: '',
    uom: 'piece',
    primitive_quantity: 1,
    units_per_packaging: 1,
    expiry_date: '',
    status: 'active'
  };
  editingId: number | null = null;
  canEditBarcode: boolean = false;

  showCreateForm() {
    this.showForm = true;
    this.editMode = false;
    this.productForm = {
      name: '',
      brand: '',
      manufacturer: '',
      description: '',
      barcode: '',
      price: 0,
      cost_price: 0,
      selling_price: 0,
      mrp: 0,
      category_id: null,
      image: '',
      uom: 'piece',
      primitive_quantity: 1,
      units_per_packaging: 1,
      expiry_date: '',
      status: 'active'
    };
    this.editingId = null;
    this.canEditBarcode = false;
  }

  showEditForm(product: Product) {
    this.showForm = true;
    this.editMode = true;
    this.productForm = {
      name: product.name,
      brand: product.brand || '',
      manufacturer: product.manufacturer || '',
      description: product.description || '',
      barcode: product.barcode || '',
      price: product.price,
      cost_price: product.cost_price || 0,
      selling_price: product.selling_price || 0,
      mrp: product.mrp || 0,
      category_id: product.category_id,
      image: product.image || '',
      uom: product.uom || 'piece',
      primitive_quantity: product.primitive_quantity || 1,
      units_per_packaging: product.units_per_packaging || 1,
      expiry_date: product.expiry_date ? product.expiry_date.split('T')[0] : '',
      status: product.status || 'active'
    };
    this.editingId = product.id;
    this.canEditBarcode = true;
  }

  saveProduct() {
    if (!this.productForm.name.trim()) {
      alert('Please enter a product name');
      return;
    }
    if (!this.productForm.category_id) {
      alert('Please select a category');
      return;
    }
    if (this.productForm.price <= 0) {
      alert('Please enter a valid price');
      return;
    }

    const productData: any = {
      name: this.productForm.name,
      brand: this.productForm.brand || null,
      manufacturer: this.productForm.manufacturer || null,
      description: this.productForm.description || null,
      barcode: this.productForm.barcode || null,
      price: this.productForm.price,
      cost_price: this.productForm.cost_price || null,
      selling_price: this.productForm.selling_price || null,
      mrp: this.productForm.mrp || null,
      category_id: this.productForm.category_id,
      image: this.productForm.image || null,
      uom: this.productForm.uom,
      primitive_quantity: this.productForm.primitive_quantity,
      units_per_packaging: this.productForm.units_per_packaging,
      expiry_date: this.productForm.expiry_date || null,
      status: this.productForm.status
    };

    if (this.editMode && this.editingId) {
      this.productService.updateProduct(this.editingId, productData).subscribe({
        next: () => {
          this.loadProducts();
          this.cancelForm();
          alert('Product updated successfully!');
        },
        error: (error) => {
          alert('Failed to update product: ' + (error.error?.message || 'Unknown error'));
        }
      });
    } else {
      this.productService.createProduct(productData).subscribe({
        next: () => {
          this.loadProducts();
          this.cancelForm();
          alert('Product created successfully!');
        },
        error: (error) => {
          alert('Failed to create product: ' + (error.error?.message || 'Unknown error'));
        }
      });
    }
  }

  cancelForm() {
    this.showForm = false;
    this.productForm = {
      name: '',
      brand: '',
      manufacturer: '',
      description: '',
      barcode: '',
      price: 0,
      cost_price: 0,
      selling_price: 0,
      mrp: 0,
      category_id: null,
      image: '',
      uom: 'piece',
      primitive_quantity: 1,
      units_per_packaging: 1,
      expiry_date: '',
      status: 'active'
    };
    this.editingId = null;
  }
}