import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Category {
  id: number;
  name: string;
  unique_id: string;
  parent_category_id?: number | null;
  parent_category_name?: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface CategoryResponse {
  success: boolean;
  message?: string;
  data: {
    category?: Category;
    categories?: Category[];
    pagination?: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
    };
  };
}

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private apiUrl = `${environment.apiUrl}/categories`;

  constructor(private http: HttpClient) {}

  getCategories(page: number = 1, limit: number = 10): Observable<CategoryResponse> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('limit', limit.toString());

    return this.http.get<CategoryResponse>(this.apiUrl, { params });
  }

  getAllCategories(): Observable<CategoryResponse> {
    return this.http.get<CategoryResponse>(`${this.apiUrl}/all`);
  }

  getCategory(id: number): Observable<CategoryResponse> {
    return this.http.get<CategoryResponse>(`${this.apiUrl}/${id}`);
  }

  createCategory(name: string, parent_category_id?: number | null, status?: string): Observable<CategoryResponse> {
    const body: any = { name };
    if (parent_category_id) body.parent_category_id = parent_category_id;
    if (status) body.status = status;
    return this.http.post<CategoryResponse>(this.apiUrl, body);
  }

  updateCategory(id: number, name: string, parent_category_id?: number | null, status?: string): Observable<CategoryResponse> {
    const body: any = { name };
    if (parent_category_id) body.parent_category_id = parent_category_id;
    if (status) body.status = status;
    return this.http.put<CategoryResponse>(`${this.apiUrl}/${id}`, body);
  }

  deleteCategory(id: number): Observable<CategoryResponse> {
    return this.http.delete<CategoryResponse>(`${this.apiUrl}/${id}`);
  }
}