import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Product {
  id: number;
  name: string;
  image: string;
  price: number;
  unique_id: string;
  category_id: number;
  category_name?: string;
  brand?: string;
  manufacturer?: string;
  description?: string;
  barcode?: string;
  uom?: string;
  primitive_quantity?: number;
  units_per_packaging?: number;
  cost_price?: number;
  selling_price?: number;
  mrp?: number;
  expiry_date?: string;
  status?: string;
  created_at: string;
  updated_at: string;
}

export interface ProductResponse {
  success: boolean;
  message?: string;
  data: {
    product?: Product;
    products?: Product[];
    pagination?: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
    };
  };
}

export interface BulkUploadResponse {
  success: boolean;
  message: string;
  data: {
    totalProducts: number;
    processedProducts: number;
    failedProducts: number;
    validationErrors: any[] | null;
    processingErrors: any[] | null;
  };
}

export interface ProductFilters {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  search?: string;
  category_id?: number;
  status?: string;
}

export interface ProductCreate {
  name: string;
  price: number;
  category_id: number;
  brand?: string;
  manufacturer?: string;
  description?: string;
  barcode?: string;
  image?: string;
  uom?: string;
  primitive_quantity?: number;
  units_per_packaging?: number;
  cost_price?: number;
  selling_price?: number;
  mrp?: number;
  expiry_date?: string;
  status?: string;
}

export interface ProductUpdate {
  name?: string;
  price?: number;
  category_id?: number;
  brand?: string;
  manufacturer?: string;
  description?: string;
  barcode?: string;
  image?: string;
  uom?: string;
  primitive_quantity?: number;
  units_per_packaging?: number;
  cost_price?: number;
  selling_price?: number;
  mrp?: number;
  expiry_date?: string;
  status?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = `${environment.apiUrl}/products`;

  constructor(private http: HttpClient) {}

  getProducts(filters: ProductFilters = {}): Observable<ProductResponse> {
    let params = new HttpParams();

    if (filters.page) params = params.set('page', filters.page.toString());
    if (filters.limit) params = params.set('limit', filters.limit.toString());
    if (filters.sortBy) params = params.set('sortBy', filters.sortBy);
    if (filters.sortOrder) params = params.set('sortOrder', filters.sortOrder);
    if (filters.search) params = params.set('search', filters.search);
    if (filters.category_id) params = params.set('category_id', filters.category_id.toString());
    if (filters.status) params = params.set('status', filters.status);

    return this.http.get<ProductResponse>(this.apiUrl, { params });
  }

  getProduct(id: number): Observable<ProductResponse> {
    return this.http.get<ProductResponse>(`${this.apiUrl}/${id}`);
  }

  createProduct(product: ProductCreate): Observable<ProductResponse> {
    return this.http.post<ProductResponse>(this.apiUrl, product);
  }

  updateProduct(id: number, product: ProductUpdate): Observable<ProductResponse> {
    return this.http.put<ProductResponse>(`${this.apiUrl}/${id}`, product);
  }

  deleteProduct(id: number): Observable<ProductResponse> {
    return this.http.delete<ProductResponse>(`${this.apiUrl}/${id}`);
  }

  bulkUpload(file: File): Observable<BulkUploadResponse> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<BulkUploadResponse>(`${this.apiUrl}/bulk-upload`, formData);
  }

  downloadReport(format: 'csv' | 'xlsx'): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/report?format=${format}`, {
      responseType: 'blob'
    });
  }

  downloadReportAsFile(format: 'csv' | 'xlsx'): void {
    this.downloadReport(format).subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `products-report.${format}`;
        link.click();
        window.URL.revokeObjectURL(url);
      },
      error: (error) => {
        console.error('Error downloading report:', error);
        alert('Failed to download report. Please try again.');
      }
    });
  }
}